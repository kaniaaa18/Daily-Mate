package com.example.dailymate.Data.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.dailymate.Data.entity.Note;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "activities.db";
    private static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE activities (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, time LONG)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS activities");
        onCreate(db);
    }

    // Menambahkan aktivitas baru
    public long insertActivity(String title, String description, long time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("description", description);
        values.put("time", time);
        return db.insert("activities", null, values);
    }

    // Mendapatkan semua aktivitas
    public List<Note> getAllActivities() {
        List<Note> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM activities ORDER BY time ASC", null);
        while (cursor.moveToNext()) {
            list.add(new Note(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getLong(3)
            ));
        }
        cursor.close();
        return list;
    }

    // Mendapatkan aktivitas berdasarkan ID
    public Note getActivityById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM activities WHERE id = ?", new String[]{String.valueOf(id)});
        if (cursor != null && cursor.moveToFirst()) {
            Note activity = new Note(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getLong(3)
            );
            cursor.close();
            return activity;
        }
        return null;
    }

    // Memperbarui aktivitas berdasarkan ID
    public void updateActivity(long id, String title, String description, long time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("description", description);
        values.put("time", time);

        db.update("activities", values, "id = ?", new String[]{String.valueOf(id)});
    }

    // Hapus aktivitas berdasarkan ID
    public void deleteActivity(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("activities", "id = ?", new String[]{String.valueOf(id)});
    }
}